<?php
include '../../koneksi.php';
include '../auth.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $judul   = $_POST['judul'];
  $isi     = $_POST['isi'];
  $tanggal = $_POST['tanggal'];
  $gambar  = $_FILES['gambar']['name'];
  $tmp     = $_FILES['gambar']['tmp_name'];

  if ($gambar) {
    move_uploaded_file($tmp, "../../assets/img/" . $gambar);
  }

  $sql = "INSERT INTO artikel (judul, isi, tanggal, gambar) 
          VALUES ('$judul', '$isi', '$tanggal', '$gambar')";

  if ($koneksi->query($sql)) {
    header("Location: index.php?success=1");
  } else {
    $error = "Gagal simpan artikel: " . $koneksi->error;
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Artikel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0">Tambah Artikel</h2>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">Judul</label>
          <input type="text" name="judul" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Isi</label>
          <textarea name="isi" class="form-control" rows="6" required></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">Tanggal</label>
          <input type="date" name="tanggal" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Gambar</label>
          <input type="file" name="gambar" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Simpan Artikel</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
