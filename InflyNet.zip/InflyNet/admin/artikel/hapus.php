<?php
include '../../koneksi.php';
include '../auth.php';

$id = $_GET['id'];
$sql = "SELECT gambar FROM artikel WHERE id = $id";
$result = $koneksi->query($sql);
$data = $result->fetch_assoc();

if ($data && file_exists("../../assets/img/" . $data['gambar'])) {
  unlink("../../assets/img/" . $data['gambar']);
}

$sql = "DELETE FROM artikel WHERE id = $id";
$koneksi->query($sql);

header("Location: index.php?deleted=1");
exit;
?>
