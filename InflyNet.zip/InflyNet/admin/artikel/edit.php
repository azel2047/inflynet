<?php
include '../../koneksi.php';
include '../auth.php';

$id = $_GET['id'];
$sql = "SELECT * FROM artikel WHERE id = $id";
$result = $koneksi->query($sql);
$data = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $judul = $_POST['judul'];
  $isi = $_POST['isi'];
  $tanggal = $_POST['tanggal'];
  $gambar = $_FILES['gambar']['name'];
  $tmp = $_FILES['gambar']['tmp_name'];

  if ($gambar) {
    move_uploaded_file($tmp, "../../assets/img/" . $gambar);
  } else {
    $gambar = $data['gambar']; // gunakan gambar lama
  }

  $sql = "UPDATE artikel SET judul='$judul', isi='$isi', tanggal='$tanggal', gambar='$gambar' WHERE id=$id";
  if ($koneksi->query($sql)) {
    header("Location: index.php?updated=1");
  } else {
    $error = "Gagal mengupdate data: " . $koneksi->error;
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Artikel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
<div class="container">
  <h2>Edit Artikel</h2>
  <?php if (!empty($error)) echo '<div class="alert alert-danger">' . $error . '</div>'; ?>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">Judul</label>
      <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($data['judul']) ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Isi</label>
      <textarea name="isi" class="form-control" rows="6" required><?= htmlspecialchars($data['isi']) ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Tanggal</label>
      <input type="date" name="tanggal" class="form-control" value="<?= $data['tanggal'] ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Gambar</label>
      <input type="file" name="gambar" class="form-control">
      <div class="mt-2"><img src="../../assets/img/<?= $data['gambar'] ?>" width="100"></div>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Batal</a>
  </form>
</div>
</body>
</html>
