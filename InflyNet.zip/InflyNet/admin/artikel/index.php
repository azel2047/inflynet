<?php
include '../../koneksi.php'; 
include '../auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Artikel - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body.light-mode { background-color: #f8f9fa; color: #212529; }
    body.dark-mode { background-color: #121212; color: #f1f1f1; }
    .dark-mode .card, 
    .dark-mode .table, 
    .dark-mode .table th, 
    .dark-mode .table td {
      background-color: #1e1e1e !important;
      color: #f1f1f1 !important;
    }
    .dark-mode .btn-secondary, .dark-mode .btn-success {
      border-color: #fff;
    }
    body {
      background: linear-gradient(to right, rgb(171, 72, 187), rgb(123, 43, 141));
      transition: background 0.5s ease;
    }
    .mode-switch {
      position: fixed;
      top: 15px;
      right: 20px;
      z-index: 999;
    }
  </style>
</head>
<body class="p-4 light-mode">

<!-- Dark Mode Toggle -->
<div class="mode-switch">
  <label class="form-check form-switch">
    <input class="form-check-input" type="checkbox" id="modeToggle">
    <span class="form-check-label">🌙</span>
  </label>
</div>

<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0 text-white">📰 Kelola Artikel</h2>
    <a href="../index.php" class="btn btn-outline-light">⬅️ Dashboard</a>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">📄 Daftar Artikel</h5>
        <a href="tambah.php" class="btn btn-success">+ Tambah Artikel</a>
      </div>

      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="table-primary">
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Gambar</th>
              <th>Tanggal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $sql = "SELECT * FROM artikel ORDER BY id DESC";
            $result = $koneksi->query($sql);
            $no = 1;

            if ($result && $result->num_rows > 0):
              while ($row = $result->fetch_assoc()):
            ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= htmlspecialchars($row['judul']) ?></td>
              <td>
                <?php if (!empty($row['gambar'])): ?>
                  <img src="../../assets/img/<?= $row['gambar'] ?>" width="100" class="img-thumbnail">
                <?php else: ?>
                  <em>Tanpa gambar</em>
                <?php endif; ?>
              </td>
              <td><?= $row['tanggal'] ?></td>
              <td>
                <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus artikel ini?')">Hapus</a>
              </td>
            </tr>
            <?php endwhile; else: ?>
            <tr>
              <td colspan="5" class="text-center">Belum ada data artikel.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>

<script>
  const toggle = document.getElementById('modeToggle');
  const body = document.body;

  const savedMode = localStorage.getItem('mode');
  if (savedMode === 'dark') {
    body.classList.remove('light-mode');
    body.classList.add('dark-mode');
    toggle.checked = true;
  }

  toggle.addEventListener('change', () => {
    if (toggle.checked) {
      body.classList.remove('light-mode');
      body.classList.add('dark-mode');
      localStorage.setItem('mode', 'dark');
    } else {
      body.classList.remove('dark-mode');
      body.classList.add('light-mode');
      localStorage.setItem('mode', 'light');
    }
  });
</script>

</body>
</html>
