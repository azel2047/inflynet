<?php
include '../../koneksi.php';

// Validasi apakah parameter id ada
if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan'); window.location.href='index.php';</script>";
    exit;
}

$id = $_GET['id'];

// Ambil data berdasarkan ID
$query = "SELECT * FROM kontak WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<script>alert('Data tidak ditemukan'); window.location.href='index.php';</script>";
    exit;
}

$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Pesan - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #764ba2, #667eea);
            color: #fff;
        }
        .card {
            background-color:rgb(253, 253, 253);
        }
    </style>
</head>
<body class="p-4">
    <div class="container">
        <a href="kontak_pesan.php" class="btn btn-light mb-3">⬅️ Kembali ke Daftar Pesan</a>

        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="card-title mb-3">📬 Detail Pesan Masuk</h4>
                <p><strong>Nama:</strong> <?= htmlspecialchars($data['nama']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($data['email']) ?></p>
                <p><strong>Tanggal:</strong> <?= $data['tanggal'] ?></p>
                <hr>
                <p><strong>Isi Pesan:</strong></p>
                <p><?= nl2br(htmlspecialchars($data['pesan'])) ?></p>
            </div>
        </div>
    </div>
</body>
</html>
