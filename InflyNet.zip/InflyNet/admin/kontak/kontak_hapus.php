<?php
include '../../koneksi.php'; // Pastikan koneksi ke database

// Mengecek apakah id ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus pesan berdasarkan id
    $query = "DELETE FROM kontak WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Pesan berhasil dihapus!'); window.location.href='kontak_pesan.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus pesan.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('ID pesan tidak ditemukan.'); window.history.back();</script>";
}
?>
