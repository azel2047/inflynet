<?php
include '../../koneksi.php';
include '../auth.php';

// Ambil ID produk dari parameter URL
$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Ambil data produk dari database
$sql = "SELECT * FROM produk WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$produk = $result->fetch_assoc();

if (!$produk) {
    echo "Produk tidak ditemukan.";
    exit;
}

// Proses update data jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_produk = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];
    $deskripsi2 = $_POST['deskripsi2'];
    $deskripsi3 = $_POST['deskripsi3'];
    $deskripsi4 = $_POST['deskripsi4'];
    $deskripsi5 = $_POST['deskripsi5'];

    $sql = "UPDATE produk SET nama_produk = ?, harga = ?, deskripsi = ?, deskripsi2 = ?, deskripsi3 = ?, deskripsi4 = ?, deskripsi5 = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("sssssssi", $nama_produk, $harga, $deskripsi, $deskripsi2, $deskripsi3, $deskripsi4, $deskripsi5, $id);

    if ($stmt->execute()) {
        header('Location: index.php');
        exit;
    } else {
        echo "Terjadi kesalahan saat mengupdate data: " . $koneksi->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container">
    <h2>Edit Produk</h2>

    <form action="" method="POST">
        <div class="mb-3">
            <label for="nama_produk" class="form-label">Nama Produk</label>
            <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?= htmlspecialchars($produk['nama_produk']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="harga" class="form-label">Harga Produk</label>
            <input type="text" class="form-control" id="harga" name="harga" value="<?= htmlspecialchars($produk['harga']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi Produk</label>
            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required><?= htmlspecialchars($produk['deskripsi']) ?></textarea>
        </div>

        <div class="mb-3">
            <label for="deskripsi2" class="form-label">Deskripsi Produk 2</label>
            <textarea class="form-control" id="deskripsi2" name="deskripsi2" rows="3" required><?= htmlspecialchars($produk['deskripsi2']) ?></textarea>
        </div>

        <div class="mb-3">
            <label for="deskripsi3" class="form-label">Deskripsi Produk 3</label>
            <textarea class="form-control" id="deskripsi3" name="deskripsi3" rows="3" required><?= htmlspecialchars($produk['deskripsi3']) ?></textarea>
        </div>

        <div class="mb-3">
            <label for="deskripsi4" class="form-label">Deskripsi Produk 4</label>
            <textarea class="form-control" id="deskripsi4" name="deskripsi4" rows="3" required><?= htmlspecialchars($produk['deskripsi4']) ?></textarea>
        </div>

        <div class="mb-3">
            <label for="deskripsi5" class="form-label">Deskripsi Produk 5</label>
            <textarea class="form-control" id="deskripsi5" name="deskripsi5" rows="3" required><?= htmlspecialchars($produk['deskripsi5']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update Produk</button>
    </form>
</div>

</body>
</html>
