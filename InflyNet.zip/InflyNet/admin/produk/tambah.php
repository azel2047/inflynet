<?php
include '../../koneksi.php';
include '../auth.php';

// Logika untuk menambahkan produk
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nama_produk = $_POST['nama_produk'];
  $deskripsi = $_POST['deskripsi'];
  $deskripsi2 = $_POST['deskripsi2'];
  $deskripsi3 = $_POST['deskripsi3'];
  $deskripsi4 = $_POST['deskripsi4'];
  $deskripsi5 = $_POST['deskripsi5'];
  $harga = $_POST['harga']; // Menambahkan harga

    // Menyimpan produk ke database
    $sql = "INSERT INTO produk (nama_produk, deskripsi, deskripsi2, deskripsi3, deskripsi4, deskripsi5, harga) VALUES (?, ?, ?, ?, ?, ?, ?)";
    // Menggunakan prepared statement untuk menghindari SQL injection
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("sssssss", $nama_produk, $deskripsi, $deskripsi2, $deskripsi3, $deskripsi4, $deskripsi5, $harga);

    if ($stmt->execute()) {
      header('Location: index.php');
      exit;
    } else {
      echo "Terjadi kesalahan saat menyimpan data: " . $koneksi->error;
    }
  }

?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Produk - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container">
  <h2>Tambah Produk</h2>

  <form action="tambah.php" method="POST" enctype="multipart/form-data">
  <div class="mb-3">
    <label for="nama_produk" class="form-label">Nama Produk</label>
    <input type="text" class="form-control" id="nama_produk" name="nama_produk" required>
  </div>

  <div class="mb-3">
    <label for="harga" class="form-label">Harga Produk</label>
    <input type="text" class="form-control" id="harga" name="harga" required>
  </div>
<!-- Deskripsi Produk -->
  <div class="mb-3">
    <label for="deskripsi" class="form-label">Deskripsi Produk</label>
    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
  </div>
  <div class="mb-3">
    <label for="deskripsi2" class="form-label">Deskripsi Produk2</label>
    <textarea class="form-control" id="deskripsi2" name="deskripsi2" rows="3" required></textarea>
  </div>
  <div class="mb-3">
    <label for="deskripsi3" class="form-label">Deskripsi Produk3</label>
    <textarea class="form-control" id="deskripsi3" name="deskripsi3" rows="3" required></textarea>
  </div>
  <div class="mb-3">
    <label for="deskripsi4" class="form-label">Deskripsi Produk4</label>
    <textarea class="form-control" id="deskripsi4" name="deskripsi4" rows="3" ></textarea>
  </div>
  <div class="mb-3">
    <label for="deskripsi5" class="form-label">Deskripsi Produk5</label>
    <textarea class="form-control" id="deskripsi5" name="deskripsi5" rows="3" ></textarea>
  </div>

  <button type="submit" class="btn btn-primary">Tambahkan Produk</button>
</form>
</div>

</body>
</html>
