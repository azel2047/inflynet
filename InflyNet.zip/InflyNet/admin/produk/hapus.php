<?php
include '../../koneksi.php';
include '../auth.php';

// Ambil ID dari parameter URL
$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Cek apakah produk dengan ID tersebut ada
$sql = "SELECT * FROM produk WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$produk = $result->fetch_assoc();

if (!$produk) {
    echo "Produk tidak ditemukan.";
    exit;
}

// Hapus data dari database
$sql = "DELETE FROM produk WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header('Location: index.php');
    exit;
} else {
    echo "Terjadi kesalahan saat menghapus produk: " . $koneksi->error;
}
?>
