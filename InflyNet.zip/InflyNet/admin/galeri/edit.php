<?php
include '../../koneksi.php';
include '../auth.php';

$id = $_GET['id'];
$sql = "SELECT * FROM galeri WHERE id = $id";
$result = $koneksi->query($sql);
$data = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $judul = $_POST['judul'];
  $gambar = $_FILES['gambar']['name'];
  $tmp = $_FILES['gambar']['tmp_name'];

  if ($gambar) {
    move_uploaded_file($tmp, "../../assets/img/" . $gambar);
    $sqlUpdate = "UPDATE galeri SET judul='$judul', gambar='$gambar' WHERE id=$id";
  } else {
    $sqlUpdate = "UPDATE galeri SET judul='$judul' WHERE id=$id";
  }

  if ($koneksi->query($sqlUpdate)) {
    echo "<script>alert('Data berhasil diperbarui'); window.location='index.php';</script>";
  } else {
    echo "<div class='alert alert-danger'>Gagal memperbarui data.</div>";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Galeri</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
<div class="container">
  <h2>Edit Galeri</h2>
  <a href="index.php" class="btn btn-secondary mb-3">Kembali</a>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">Judul</label>
      <input type="text" name="judul" class="form-control" value="<?= htmlspecialchars($data['judul']) ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Gambar</label>
      <input type="file" name="gambar" class="form-control">
      <small class="text-muted">Biarkan kosong jika tidak ingin mengubah gambar.</small>
    </div>
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
  </form>
</div>
</body>
</html>
