<?php
include '../../koneksi.php';
include '../auth.php';

$id = $_GET['id'];
$sql = "SELECT gambar FROM galeri WHERE id = $id";
$result = $koneksi->query($sql);
$data = $result->fetch_assoc();

if ($data && file_exists("../../assets/img/" . $data['gambar'])) {
  unlink("../../assets/img/" . $data['gambar']);
}

$koneksi->query("DELETE FROM galeri WHERE id = $id");
header("Location: index.php");
exit;
