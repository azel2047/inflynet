<?php
include 'auth.php';
include '../koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body.light-mode { background-color: #f8f9fa; color: #212529; }
    body.dark-mode { background-color: #121212; color: #f1f1f1; }
    .dark-mode .card, .dark-mode .list-group-item { background-color: #1e1e1e; color: #fff; }
    .mode-switch { position: fixed; top: 15px; right: 20px; z-index: 999; }
    body {
      background: linear-gradient(to right, rgb(171, 72, 187), rgb(123, 43, 141));
      padding-bottom: 50px;
    }
    .card-title {
      font-size: 1.2rem;
    }
  </style>
</head>
<body class="p-4">

<div class="mode-switch">
  <label class="form-check form-switch">
    <input class="form-check-input" type="checkbox" id="modeToggle">
    <span class="form-check-label">🌙</span>
  </label>
</div>

<div class="container">
  <h2 class="mb-4">📊 Dashboard Admin</h2>
  <div class="row g-4 justify-content-center">

    <!-- Profil -->
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">👤 Profil</h5>
          <p class="card-text">Ganti Profil</p>
          <a href="logo/" class="btn btn-sm btn-outline-primary">Kelola</a>
        </div>
      </div>
    </div>

    <!-- Produk -->
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📦 Produk</h5>
          <p class="card-text">
            <?php
              $totalProduk = $koneksi->query("SELECT COUNT(*) as total FROM produk")->fetch_assoc()['total'];
              echo "<strong>$totalProduk</strong> Produk";
            ?>
          </p>
          <a href="produk/" class="btn btn-sm btn-outline-primary">Kelola</a>
        </div>
      </div>
    </div>

    <!-- Tentang Kami -->
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📝 Tentang Kami</h5>
          <p class="card-text">
            <?php
              $totalTentangKami = $koneksi->query("SELECT COUNT(*) as total FROM tentang_kami_box")->fetch_assoc()['total'];
              echo "<strong>$totalTentangKami</strong> Tentang Kami";
            ?>
          </p>
          <a href="tentang_kami_box/" class="btn btn-sm btn-outline-primary">Kelola</a>
        </div>
      </div>
    </div>

    <!-- Artikel -->
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📝 Artikel</h5>
          <p class="card-text">
            <?php
              $totalArtikel = $koneksi->query("SELECT COUNT(*) as total FROM artikel")->fetch_assoc()['total'];
              echo "<strong>$totalArtikel</strong> Artikel";
            ?>
          </p>
          <a href="artikel/" class="btn btn-sm btn-outline-primary">Kelola</a>
        </div>
      </div>
    </div>

    <!-- Galeri -->
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">🖼️ Galeri</h5>
          <p class="card-text">
            <?php
              $totalGaleri = $koneksi->query("SELECT COUNT(*) as total FROM galeri")->fetch_assoc()['total'];
              echo "<strong>$totalGaleri</strong> Gambar";
            ?>
          </p>
          <a href="galeri/" class="btn btn-sm btn-outline-primary">Kelola</a>
        </div>
      </div>
    </div>

   <!-- Kontak -->
<div class="col-md-3">
  <div class="card shadow-sm">
    <div class="card-body">
      <h5 class="card-title">📬 Kontak</h5>
      <p class="card-text">
        <?php
          $totalKontak = $koneksi->query("SELECT COUNT(*) as total FROM kontak")->fetch_assoc()['total'];
          echo "<strong>$totalKontak</strong> Pesan Masuk";
        ?>
      </p>
      <a href="kontak/kontak_pesan.php" class="btn btn-sm btn-outline-primary">Kelola</a>
    </div>
  </div>
</div>


  <!-- Statistik & Info Admin -->
  <div class="row my-5">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📈 Statistik Data Mingguan</h5>
          <canvas id="dataChart" height="100"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">👤 Info Admin</h5>
          <ul class="list-group small">
            <li class="list-group-item">Nama: <strong>Admin</strong></li>
            <li class="list-group-item">Login terakhir: <strong><?= date('d/m/Y H:i') ?></strong></li>
            <li class="list-group-item">Status: <span class="badge bg-success">Aktif</span></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <!-- Logout Buttons -->
  <div class="d-flex justify-content-between mt-4">
    <a href="../index.php" class="btn btn-outline-secondary">🔙 Lihat Halaman User</a>
    <a href="logout.php" class="btn btn-danger">🚪 Logout</a>
  </div>

</div>

<script>
  const dataCtx = document.getElementById('dataChart').getContext('2d');
  const dataChart = new Chart(dataCtx, {
    type: 'bar',
    data: {
      labels: ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'],
      datasets: [
        {
          label: 'Produk',
          data: [5, 7, 3, 4, 6, 2, 4],
          backgroundColor: 'rgba(13, 110, 253, 0.7)'
        },
        {
          label: 'Artikel',
          data: [2, 4, 1, 3, 2, 1, 3],
          backgroundColor: 'rgba(25, 135, 84, 0.7)'
        },
        {
          label: 'Galeri',
          data: [3, 2, 5, 2, 1, 4, 2],
          backgroundColor: 'rgba(255, 193, 7, 0.7)'
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });

  // Dark/Light Mode Toggle
  const toggle = document.getElementById('modeToggle');
  const body = document.body;
  const savedMode = localStorage.getItem('mode');
  if (savedMode === 'dark') {
    body.classList.add('dark-mode');
    toggle.checked = true;
  }

  toggle.addEventListener('change', () => {
    if (toggle.checked) {
      body.classList.add('dark-mode');
      body.classList.remove('light-mode');
      localStorage.setItem('mode', 'dark');
    } else {
      body.classList.remove('dark-mode');
      body.classList.add('light-mode');
      localStorage.setItem('mode', 'light');
    }
  });
</script>

</body>
</html>
