<?php
include '../../koneksi.php';
include '../auth.php';

// Ambil ID dari parameter URL
$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Cek apakah data dengan ID tersebut ada
$sql = "SELECT * FROM tentang_kami_box WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    echo "Data tidak ditemukan.";
    exit;
}

// Hapus data dari database
$sql = "DELETE FROM tentang_kami_box WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header('Location: index.php');
    exit;
} else {
    echo "Terjadi kesalahan saat menghapus data: " . $koneksi->error;
}
?>
