<?php
include '../../koneksi.php';
include '../auth.php';

// Ambil ID dari parameter URL
$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Ambil data dari database
$sql = "SELECT * FROM tentang_kami_box WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    echo "Data tidak ditemukan!";
    exit;
}

// Proses update data jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ikon = $_POST['ikon'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];

    $sql = "UPDATE tentang_kami_box SET ikon = ?, judul = ?, deskripsi = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("sssi", $ikon, $judul, $deskripsi, $id);

    if ($stmt->execute()) {
        header("Location: index.php");
        exit;
    } else {
        echo "Terjadi kesalahan saat mengupdate data: " . $koneksi->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Tentang Kami</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">

<div class="container">
    <h2>Edit Tentang Kami</h2>

    <form method="POST">
        <div class="mb-3">
            <label for="ikon" class="form-label">Ikon (class bootstrap icon):</label>
            <input type="text" class="form-control" id="ikon" name="ikon" value="<?= htmlspecialchars($data['ikon']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="judul" class="form-label">Judul:</label>
            <input type="text" class="form-control" id="judul" name="judul" value="<?= htmlspecialchars($data['judul']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi:</label>
            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="5" required><?= htmlspecialchars($data['deskripsi']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    </form>
</div>

</body>
</html>
