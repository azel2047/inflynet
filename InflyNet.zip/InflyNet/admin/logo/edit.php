<?php
include '../../koneksi.php';
include '../auth.php';

// Ambil data logo
$sql = "SELECT * FROM site_settings LIMIT 1";
$result = $koneksi->query($sql);
$data = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $logo = $_FILES['logo']['name'];
  $tmp = $_FILES['logo']['tmp_name'];

  if ($logo) {
    $tujuan = "../../assets/" . $logo;
    move_uploaded_file($tmp, $tujuan);

    $sqlUpdate = "UPDATE site_settings SET logo_path='assets/$logo'";
    if ($koneksi->query($sqlUpdate)) {
      echo "<script>alert('Logo berhasil diperbarui'); window.location='index.php';</script>";
    } else {
      echo "<div class='alert alert-danger'>Gagal memperbarui logo.</div>";
    }
  } else {
    echo "<div class='alert alert-warning'>Silakan pilih file logo untuk diunggah.</div>";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Logo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
<div class="container">
  <h2>Edit Logo Website</h2>
  <a href="index.php" class="btn btn-secondary mb-3">⬅️ Kembali</a>
  
  <form method="post" enctype="multipart/form-data" action="edit_proses.php">
  <div class="mb-3">
  <label class="form-label">Logo Saat Ini</label><br>
  <img src="<?= $setting['logo_path'] ?>" alt="Logo" class="img-fluid" style="height: 100px !important; max-height: none;">
  </div>

    
  <div class="mb-3">
  <label class="form-label">Ganti Logo</label>
  <input type="file" name="logo" class="form-control" accept=".jpg,.jpeg,.png,image/jpeg,image/png" required>
  <small class="text-muted">Format gambar: PNG, JPG. Maksimal ukuran tergantung server.</small>
  </div>

    
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
  </form>
</div>
</body>
</html>
