<?php
include '../../koneksi.php';
include '../auth.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $logo = $_FILES['logo']['name'];
    $tmp = $_FILES['logo']['tmp_name'];

    if ($logo) {
        $tujuan = "../../assets/" . $logo;
        $path_db = "assets/" . $logo;

        if (move_uploaded_file($tmp, $tujuan)) {
            $sqlUpdate = "UPDATE site_settings SET logo_path='$path_db'";

            if ($koneksi->query($sqlUpdate)) {
                echo "<script>alert('Logo berhasil diperbarui'); window.location='index.php';</script>";
            } else {
                echo "<script>alert('Gagal menyimpan ke database'); window.location='edit.php';</script>";
            }
        } else {
            echo "<script>alert('Gagal mengunggah file'); window.location='edit.php';</script>";
        }
    } else {
        echo "<script>alert('Silakan pilih file logo'); window.location='edit.php';</script>";
    }
} else {
    header("Location: edit.php");
    exit;
}
