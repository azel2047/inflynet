<?php
include '../../koneksi.php';

if (isset($_POST['upload'])) {
    $logo_name = $_FILES['logo']['name'];
    $logo_tmp = $_FILES['logo']['tmp_name'];
    $logo_path = 'assets/' . $logo_name;

    move_uploaded_file($logo_tmp, $logo_path);

    // update logo di database
    mysqli_query($koneksi, "UPDATE site_settings SET logo_path='$logo_path'");

    echo "Logo berhasil diperbarui!";
}

// ambil logo saat ini
$query = mysqli_query($koneksi, "SELECT logo_path FROM site_settings LIMIT 1");
$data = mysqli_fetch_assoc($query);
?>

<h2>Ganti Logo Website</h2>
<form method="POST" enctype="multipart/form-data">
    <img src="<?= $data['logo_path'] ?>" alt="Logo saat ini" style="height: 80px;"><br><br>
    <input type="file" name="logo" required><br><br>
    <button type="submit" name="upload">Upload Logo Baru</button>
</form>
