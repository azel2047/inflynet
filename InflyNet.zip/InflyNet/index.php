<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>InflyNet - Internet Cepat Tanpa Hambatan</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/logo1212.png" rel="icon">
  <link href="assets/img/logo1212.png " rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<!-- Bootstrap Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">


  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">

</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">
    <?php
      include 'koneksi.php'; // File koneksi ke database
      $query = mysqli_query($koneksi, "SELECT * FROM site_settings LIMIT 1");
      $setting = mysqli_fetch_assoc($query);
      ?>

      <a href="index.php" class="logo d-flex align-items-center me-auto">
        <img src="<?= $setting['logo_path'] ?>" alt="InflyNet Logo" class="logo-img">
      </a>




      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="#hero" class="active">Beranda</a></li>
          <li><a href="#pricing">Produk</a></li>
          <li><a href="#gallery">Galery</a></li>
          <li><a href="#artikel">Artikel</a></li>
          <li><a href="#tentang">Tentang Kami</a></li>
          <li><a href="#contact">Kontak</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header>

  <main class="main">

    <!-- Tron Judul dan Gambar Section -->
    <section id="hero" class="hero section dark-background">
      <img src="assets/img/hero-bg-2.jpg" alt="" class="hero-bg">

      <div class="container">
        <div class="row gy-4 justify-content-between">
          <div class="col-lg-4 order-lg-last hero-img" data-aos="zoom-out" data-aos-delay="100">
            <img src="assets/img/logo1212.png" class="img-fluid animated" alt="">
          </div>

          <div class="col-lg-6  d-flex flex-column justify-content-center" data-aos="fade-in">
            <h1>InflyNet<span> Internet Cepat Tanpa Hambatan</span></h1>
            <p>InflyNet – Koneksi Stabil untuk Masa Depan Digital Anda
            Nikmati internet cepat, stabil, dan tanpa batas dengan InflyNet. Didesain untuk mendukung produktivitas, hiburan, dan kebutuhan digital keluarga maupun bisnis Anda.</p>
            <div class="d-flex">
            </div>
          </div>

        </div>
      </div>

      <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
        <defs>
          <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"></path>
        </defs>
        <g class="wave1">
          <use xlink:href="#wave-path" x="50" y="3"></use>
        </g>
        <g class="wave2">
          <use xlink:href="#wave-path" x="50" y="0"></use>
        </g>
        <g class="wave3">
          <use xlink:href="#wave-path" x="50" y="9"></use>
        </g>
      </svg>

    </section><!-- /Tron Judul dan Gambar Section -->

    <!-- Tentang Kami Section -->
    <?php include 'koneksi.php'; ?>
<section id="tentang" class="tentang">
  <div class="container" data-aos="fade-up">
    <div class="container section-title" data-aos="fade-up">
      <h2>Tentang Kami</h2>
      <div><span class="description-title">Tentang Kami</span></div>
    </div>
    <div class="row gy-4">
      <?php 
      $query = mysqli_query($koneksi, "SELECT * FROM tentang_kami_box WHERE id = 6");
      $row = mysqli_fetch_assoc($query);
      ?>
      <div class="col-lg-6 d-flex flex-column justify-content-center">
        <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100" style="font-size: 1.2rem; padding: 30px; width: 100%;">
        <h3 class="fw-bold" style="font-size: 2rem;"><?= $row['judul'] ?></h3>
        <span><?= $row['deskripsi'] ?></span>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="row gy-4">
        <?php
          $data = mysqli_query($koneksi, "SELECT * FROM tentang_kami_box WHERE id IN (1, 2, 3, 5) ORDER BY id ASC");
          while($row = mysqli_fetch_assoc($data)):
          ?>
            <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
              <i class="<?= htmlspecialchars($row['ikon']) ?>"></i>
              <h4 class="fw-bold"><?= htmlspecialchars($row['judul']) ?></h4>
              <p><?= htmlspecialchars($row['deskripsi']) ?></p>
            </div>
          <?php endwhile; ?>

        </div>
      </div>
    </div>
  </div>
</section>
    <!-- End Tentang Kami Section -->

    <!-- Produk Section -->
    <section id="pricing" class="pricing section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Produk</h2>
        <div><span class="description-title">Produk</span></div>

      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

        <?php
include 'koneksi.php'; // Pastikan path ini benar

$query = "SELECT * FROM produk";
$result = $koneksi->query($query);

while ($row = $result->fetch_assoc()):
?>
<div class="col-lg-4" data-aos="zoom-in" data-aos-delay="100">
  <div class="pricing-item">
    <h3><?= htmlspecialchars($row['nama_produk']) ?></h3>
    <p class="description"><?= htmlspecialchars($row['deskripsi']) ?></p>
    <h4><sup>Rp</sup><?= htmlspecialchars($row['harga']) ?><span> / bulan</span></h4>
    <ul>
      <!-- Fitur Aktif -->
      <?php if (!empty($row['deskripsi2'])): ?>
        <li><i class="bi bi-check"></i> <span><?= htmlspecialchars($row['deskripsi2']) ?></span></li>
      <?php endif; ?>
      <?php if (!empty($row['deskripsi3'])): ?>
        <li><i class="bi bi-check"></i> <span><?= htmlspecialchars($row['deskripsi3']) ?></span></li>
      <?php endif; ?>

      <!-- Fitur Tidak Aktif -->
      <?php if (!empty($row['deskripsi4'])): ?>
        <li><i class="bi bi-check"></i> <span><?= htmlspecialchars($row['deskripsi4']) ?></span></li>
      <?php endif; ?>
      <?php if (!empty($row['deskripsi5'])): ?>
        <li><i class="bi bi-check"></i> <span><?= htmlspecialchars($row['deskripsi5']) ?></span></li>
      <?php endif; ?>
    </ul>
  </div>
</div>
<?php endwhile; ?>


        </div>

      </div>

    </section><!-- /Produk Section -->

    <?php include 'koneksi.php'; ?>

<!-- Gallery Section -->
<section id="gallery" class="gallery section">

  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>Galeri</h2>
    <div><span class="description-title">Galeri</span></div>
  </div><!-- End Section Title -->

  <div class="container" data-aos="fade-up" data-aos-delay="100">
    <div class="row g-0">
      <?php
      $query = "SELECT * FROM galeri ORDER BY id DESC";
      $result = mysqli_query($koneksi, $query);

      if (mysqli_num_rows($result) > 0):
        while ($row = mysqli_fetch_assoc($result)):
          $gambar = htmlspecialchars($row['gambar']);
      ?>
      <div class="col-lg-3 col-md-4">
        <div class="gallery-item">
          <a href="assets/img/<?= $gambar ?>" class="glightbox" data-gallery="images-gallery">
            <img src="assets/img/<?= $gambar ?>" alt="<?= htmlspecialchars($row['judul']) ?>" class="img-fluid">
          </a>
        </div>
      </div>
      <?php
        endwhile;
      else:
      ?>
        <p class="text-center">Belum ada gambar di galeri.</p>
      <?php endif; ?>
    </div>
  </div>
</section><!-- /Gallery Section -->


  <!-- Artikel Section -->
<section id="artikel" class="section">
  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>Artikel</h2>
    <div><span class="description-title">Artikel</span></div>  
  </div>
  <!-- End Section Title -->

  <div class="container">
    <div class="row gy-5">
      <?php
      include 'koneksi.php';

      $query = "SELECT * FROM artikel ORDER BY tanggal DESC";
      $result = $koneksi->query($query);

      if ($result && $result->num_rows > 0):
        $delay = 100;
        while ($row = $result->fetch_assoc()):
          // Antisipasi jika tidak ada gambar
          $gambar = !empty($row['gambar']) ? htmlspecialchars($row['gambar']) : 'default.jpg';
      ?>
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?= $delay ?>">
          <div class="member shadow-sm rounded p-2">
            <div class="pic mb-3">
              <a href="artikel_detail.php?id=<?= $row['id'] ?>">
                <img src="assets/img/<?= $gambar ?>" class="img-fluid rounded" alt="<?= htmlspecialchars($row['judul']) ?>">
              </a>
            </div>
            <div class="member-info text-center">
              <h5>
                <a href="artikel_detail.php?id=<?= $row['id'] ?>" class="text-decoration-none text-dark">
                  <?= htmlspecialchars($row['judul']) ?>
                </a>
              </h5>
              <small class="text-muted"><?= date('d M Y', strtotime($row['tanggal'])) ?></small>
              <!-- <p><?= substr(strip_tags($row['isi']), 0, 100) ?>...</p> -->
            </div>
          </div>
        </div>
      <?php
          $delay += 100;
        endwhile;
      else:
      ?>
        <div class="col-12 text-center">
          <p class="text-muted">Belum ada artikel yang tersedia saat ini.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<!-- End Artikel Section -->    

        </div>

      </div>

    <!-- Contact Section -->
    <section id="contact" class="contact section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Kontak</h2>
        <span class="description-title">Kontak</span></div>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-4">
            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-geo-alt flex-shrink-0"></i>
              <div>
                <h3>Alamat</h3>
                <p>Jln. Margonda, Depok, Jawa Barat, Indonesia</p>
              </div>
            </div><!-- End Info Item -->

            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-telephone flex-shrink-0"></i>
              <div>
                <h3>Telepom</h3>
                <p>+6285719821547</p>
              </div>
            </div><!-- End Info Item -->

            <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-envelope flex-shrink-0"></i>
              <div>
                <h3>Email</h3>
                <p>InflyNet@gmail.com</p>
              </div>
            </div><!-- End Info Item -->

          </div>

          <div class="col-lg-8">
                <form action="kontak_proses.php" method="POST">
              <div class="row">
                <div class="col-md-6 mb-3">
                  <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required>
                </div>
                <div class="col-md-6 mb-3">
                  <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
              </div>
              <div class="mb-3">
                <textarea name="pesan" rows="5" class="form-control" placeholder="Pesan..." required></textarea>
              </div>
              <div class="text-end">
                <button type="submit" class="btn btn-success">Kirim Pesan</button>
              </div>
            </form>

          </div><!-- End Contact Form -->

        </div>

      </div>

    </section><!-- /Contact Section -->

  </main>

  <footer id="footer" class="footer dark-background">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="logo d-flex align-items-center">
            <span class="sitename">InflyNet</span>
          </a>
          <div class="footer-contact pt-3">
            <p>Jln. Margonda</p>
            <p>Depok, Jawa Barat, Indonesia</p>
            <p class="mt-3"><strong>Telepon:</strong> <span>+6285719821547</span></p>
            <p><strong>Email:</strong> <span>InflyNet@gmail.com</span></p>
          </div>
          <div class="social-links d-flex mt-4">
            <a href=""><i class="bi bi-twitter-x"></i></a>
            <a href=""><i class="bi bi-facebook"></i></a>
            <a href=""><i class="bi bi-instagram"></i></a>
            <a href=""><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

        <div class="col-lg-2 col-md-3 footer-links">
          <h4>Tentang Aplikasi Ini</h4>
          <ul>
            <li><a href="#">Beranda</a></li>
            <li><a href="#">Produk</a></li>
            <li><a href="#">Galeri</a></li>
            <li><a href="#">Artikel</a></li>
            <li><a href="#">Tentang Kami</a></li>
          </ul>
        </div>
        <div class="col-lg-4 col-md-12 footer-newsletter">
          <h4>Kotak Saran</h4>
          <p>Berikan kami tentang pengalaman dan keluhan anda</p>
          <form action="forms/newsletter.php" method="post" class="php-email-form">
            <div class="newsletter-form"><input type="email" name="email"><input type="submit" value="Kirim"></div>
            <div class="loading">Loading</div>
            <div class="error-message"></div>
            <div class="sent-message">Pesan telah dikirim, Terimakasih!</div>
          </form>
        </div>

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Ugroseno Dwi Prakastyo</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
        Designed by <a href="https://bootstrapmade.com/">Ugroseno Dwi Prakastyo</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>