<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "SELECT * FROM artikel WHERE id = $id";
    $result = $koneksi->query($query);

    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        echo "<div class='container mt-5 text-center'><h2>Artikel tidak ditemukan</h2></div>";
        exit;
    }
} else {
    echo "<div class='container mt-5 text-center'><h2>ID artikel tidak valid</h2></div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($data['judul']) ?> | InflyNet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="mb-3"><?= htmlspecialchars($data['judul']) ?></h1>
            <p class="text-muted">Diterbitkan pada: <?= date('d M Y', strtotime($data['tanggal'])) ?></p>
            
            <?php if (!empty($data['gambar'])): ?>
                <img src="assets/img/<?= htmlspecialchars($data['gambar']) ?>" alt="<?= htmlspecialchars($data['judul']) ?>" class="img-fluid rounded mb-4">
            <?php endif; ?>

            <div class="content">
                <?= nl2br($data['isi']) ?>
            </div>

            <a href="index.php#artikel" class="btn btn-primary mt-4">← Kembali ke Artikel</a>
        </div>
    </div>
</div>

</body>
</html>
