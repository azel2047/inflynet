<?php 

$koneksi = mysqli_connect("localhost", "root", "", "inflynet") or die("Koneksi Gagal");

?>