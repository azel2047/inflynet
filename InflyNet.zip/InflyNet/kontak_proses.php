<?php
include 'koneksi.php'; // atau 'koneksi.php' kalau file ini 1 folder dengan form

$nama    = mysqli_real_escape_string($koneksi, $_POST['nama']);
$email   = mysqli_real_escape_string($koneksi, $_POST['email']);
$pesan   = mysqli_real_escape_string($koneksi, $_POST['pesan']);
$tanggal = date('Y-m-d H:i:s');

$query = "INSERT INTO kontak (nama, email, pesan, tanggal) VALUES ('$nama', '$email', '$pesan', '$tanggal')";
$insert = mysqli_query($koneksi, $query);

if ($insert) {
    echo "<script>alert('Pesan berhasil dikirim!'); window.location.href='index.php';</script>";
} else {
    echo "<script>alert('Gagal mengirim pesan.'); window.history.back();</script>";
}
