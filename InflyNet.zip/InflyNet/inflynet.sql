-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 23 Apr 2025 pada 07.54
-- Versi server: 8.0.30
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inflynet`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'admin', '$2y$10$JnvXb0x2CzFZUMyHDpLGV.c8B2dIvprXKpygKZX7IyVWWYxzyiLAi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id` int NOT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `isi` text,
  `tanggal` date DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id`, `judul`, `isi`, `tanggal`, `gambar`) VALUES
(1, 'Kenapa Harus Pilih InflyNet? Ini 5 Alasannya!', 'Dalam dunia yang semakin terhubung, memilih penyedia layanan internet bukan perkara sepele. Berikut ini 5 alasan mengapa InflyNet layak jadi pilihan utama Anda:\r\n\r\n1. Kecepatan Stabil\r\nInflyNet menghadirkan koneksi internet dengan kecepatan tinggi dan stabil, cocok untuk streaming, gaming, atau bekerja dari rumah.\r\n2. Layanan Pelanggan Responsif\r\nTim support kami siap membantu Anda 24/7 untuk memastikan pengalaman internet yang lancar.\r\n3. Paket Fleksibel\r\nMulai dari kebutuhan rumahan hingga bisnis skala besar, InflyNet punya berbagai pilihan paket yang bisa disesuaikan.\r\n4. Teknologi Terkini\r\nDengan jaringan berbasis fiber optic dan perangkat modern, InflyNet menjamin kualitas koneksi terbaik.\r\n5. Harga Terjangkau\r\nKualitas premium tidak harus mahal. InflyNet hadir dengan harga bersahabat untuk semua kalangan.', '2025-04-16', 'logoinflynet.png'),
(3, 'Internet Cepat untuk Bisnis Anda? Percayakan pada InflyNet!', 'Di era digital, internet bukan lagi kebutuhan tambahan—melainkan fondasi utama bisnis modern. InflyNet menyediakan layanan internet khusus untuk pelaku usaha yang butuh koneksi cepat, aman, dan stabil.\r\nBeberapa keunggulan paket bisnis kami:\r\nDedicated Bandwidth: Koneksi khusus untuk performa maksimal\r\nIP Publik Statis: Mendukung server internal dan sistem online\r\nSupport Prioritas: Tim teknis siap membantu kapan saja\r\nLayanan SLA (Service Level Agreement): Jaminan uptime dan kompensasi\r\nTingkatkan produktivitas dan efisiensi dengan InflyNet. Bisnis Anda, jaringan kami.', '2025-04-18', 'details-1.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `galeri`
--

CREATE TABLE `galeri` (
  `id` int NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `galeri`
--

INSERT INTO `galeri` (`id`, `judul`, `gambar`) VALUES
(1, 'InflyNet', 'www.png'),
(2, 'InflyNet', '1234.png'),
(3, 'InflyNet', '1111.png'),
(4, 'InflyNet', '1223.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hero`
--

CREATE TABLE `hero` (
  `id` int NOT NULL,
  `judul` text NOT NULL,
  `deskripsi` text NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kontak`
--

CREATE TABLE `kontak` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `kontak`
--

INSERT INTO `kontak` (`id`, `nama`, `email`, `pesan`, `tanggal`) VALUES
(3, 'Seeno', 'azelxiteer@gmail.com', 'Halo, Aku sangat suka dengan produk dari inflynet ini, jaringan nya lanvar dan juga sangat terjangkau\r\n', '2025-04-21 09:23:49'),
(4, 'Seno', 'senoismi5@gmail.com', 'Saya sangat suka ', '2025-04-23 05:06:31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int NOT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `harga` int DEFAULT NULL,
  `deskripsi` text,
  `deskripsi2` text,
  `deskripsi3` text,
  `deskripsi4` text,
  `deskripsi5` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `nama_produk`, `harga`, `deskripsi`, `deskripsi2`, `deskripsi3`, `deskripsi4`, `deskripsi5`) VALUES
(7, 'Paket Hemat', 499000, 'Kecepatan internet hingga 20 Mbps\r\n', 'Paket sudah termasuk langganan video berbayar dan aplikasi berbayar', 'TV berlangganan 30 program\r\n', '', ''),
(8, 'Paket Reguler', 899000, 'Kecepatan internet hingga 60 Mbps\r\n', 'Paket sudah termasuk langganan video berbayar dan aplikasi berbayar', 'TV berlangganan 30 program\r\n', '100+ pilihan program TV\r\n', ''),
(9, 'Paket Sultan', 1999000, 'Kecepatan internet hingga 100 Mbps', 'Paket sudah termasuk langganan video berbayar dan aplikasi berbayar', 'TV berlangganan 30 program', '100+ pilihan program TV', 'Kuota tidak terbatas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `site_settings`
--

CREATE TABLE `site_settings` (
  `id` int NOT NULL,
  `logo_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `site_settings`
--

INSERT INTO `site_settings` (`id`, `logo_path`) VALUES
(1, 'assets/logo1212baru-removebg-preview.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tentang_kami_box`
--

CREATE TABLE `tentang_kami_box` (
  `id` int NOT NULL,
  `ikon` varchar(100) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `deskripsi` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tentang_kami_box`
--

INSERT INTO `tentang_kami_box` (`id`, `ikon`, `judul`, `deskripsi`) VALUES
(1, 'bi bi-buildings', 'Siapakah Pelopor InflyNet', 'Pelopor sekaligus pembuat InflyNet adalah seorang siswa SMK Raflesia yang bernama Ugroseno Dwi Prakastyo Anak SMK Raflesia'),
(2, 'bi bi-clipboard-pulse', 'Berapa harga rata rata InflyNet', 'Harga InflyNet termasuk dalam kategori harga standar dengan jaringan yang berkualitas tinggi'),
(3, 'bi bi-command', 'Dimankah InflyNet dapat dibeli?', 'InflyNet dapat anda beli dan temukan di website remsi dari InflyNet'),
(5, 'bi bi-bar-chart', 'Siapa yang dapat membeli saham InflyNet?', 'Saham InflyNet dapat dibeli dan diaskes oleh semua kalangan pengguna maupun yang tidak menggunakan'),
(6, 'bi bi-buildings', 'Apa itu InflyNet?', 'InflyNet – Solusi Internet Terbaik untuk Rumah dan Bisnis Anda. Di era digital yang serba cepat ini, koneksi internet bukan lagi sekadar kebutuhan tambahan—ia adalah bagian penting dari kehidupan sehari-hari. InflyNet hadir sebagai solusi internet berkualitas tinggi yang mengutamakan kecepatan, kestabilan, dan kenyamanan untuk seluruh penggunanya.');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `hero`
--
ALTER TABLE `hero`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tentang_kami_box`
--
ALTER TABLE `tentang_kami_box`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `hero`
--
ALTER TABLE `hero`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tentang_kami_box`
--
ALTER TABLE `tentang_kami_box`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
