<?php
// koneksi ke database
session_start();
include 'koneksi.php';

// ambil data dari tabel kontak
$query = mysqli_query($koneksi, "SELECT * FROM kontak ORDER BY tanggal DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pesan Masuk - Kontak</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">Pesan Masuk</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-primary">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Pesan</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            while($row = mysqli_fetch_assoc($query)) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($row['nama']); ?></td>
                    <td><?= htmlspecialchars($row['email']); ?></td>
                    <td><?= nl2br(htmlspecialchars($row['pesan'])); ?></td>
                    <td><?= date('d-m-Y H:i', strtotime($row['tanggal'])); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
